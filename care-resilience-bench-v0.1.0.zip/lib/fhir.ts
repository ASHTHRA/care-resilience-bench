export const syntheticPatient = {
  resourceType: "Patient",
  id: "demo-patient",
  meta: { lastUpdated: "2026-09-10T14:00:00Z" },
  name: [{ use: "official", family: "Morgan", given: ["Alex"] }],
  gender: "unknown",
  birthDate: "1989-04-12",
};

export function healthyBundle() {
  return {
    resourceType: "Bundle",
    type: "collection",
    total: 3,
    entry: [
      { fullUrl: "urn:uuid:patient-demo", resource: syntheticPatient },
      {
        fullUrl: "urn:uuid:obs-bp",
        resource: {
          resourceType: "Observation",
          id: "obs-bp",
          status: "final",
          code: { text: "Blood pressure" },
          effectiveDateTime: "2026-09-10T13:30:00Z",
          valueString: "118/76 mmHg",
        },
      },
      {
        fullUrl: "urn:uuid:med-1",
        resource: {
          resourceType: "MedicationRequest",
          id: "med-1",
          status: "active",
          intent: "order",
          medicationCodeableConcept: { text: "Synthetic Medication A" },
          subject: { reference: "Patient/demo-patient" },
        },
      },
    ],
  };
}
