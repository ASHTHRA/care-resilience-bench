import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CareResilience Bench",
  description: "Open resilience and failure-testing for FHIR health-data applications.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
