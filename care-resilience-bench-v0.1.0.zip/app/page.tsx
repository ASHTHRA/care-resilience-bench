"use client";

import { useMemo, useState } from "react";

type Status = "idle" | "running" | "pass" | "fail";

type ScenarioResult = {
  key: string;
  name: string;
  layer: string;
  status: Status;
  score: number;
  durationMs?: number;
  evidence?: string;
};

const scenarios: Omit<ScenarioResult, "status" | "score">[] = [
  { key: "latency", name: "Latency spike", layer: "Network" },
  { key: "expired-token", name: "Expired OAuth token", layer: "Authorization" },
  { key: "partial-record", name: "Partial patient record", layer: "Clinical data" },
  { key: "endpoint-flap", name: "Flapping FHIR endpoint", layer: "Availability" },
  { key: "duplicate-resource", name: "Duplicate resource", layer: "Data integrity" },
  { key: "stale-data", name: "Stale clinical data", layer: "Freshness" },
];

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export default function Home() {
  const [results, setResults] = useState<ScenarioResult[]>(
    scenarios.map((scenario) => ({ ...scenario, status: "idle", score: 0 }))
  );
  const [running, setRunning] = useState(false);
  const [lastRun, setLastRun] = useState<string | null>(null);

  const completed = results.filter((item) => item.status === "pass" || item.status === "fail").length;
  const score = useMemo(() => {
    if (!completed) return 0;
    return Math.round(results.reduce((sum, item) => sum + item.score, 0) / results.length);
  }, [results, completed]);

  function patch(key: string, next: Partial<ScenarioResult>) {
    setResults((current) => current.map((item) => (item.key === key ? { ...item, ...next } : item)));
  }

  async function runScenario(key: string): Promise<{ score: number; evidence: string; durationMs: number }> {
    const started = performance.now();

    if (key === "expired-token") {
      const first = await fetch(`/api/fhir?fault=${key}&attempt=0`, { cache: "no-store" });
      if (first.status !== 401) throw new Error("Expected a 401 challenge");
      const retry = await fetch(`/api/fhir?fault=${key}&attempt=1`, { cache: "no-store" });
      if (!retry.ok) throw new Error("Token refresh retry did not recover");
      return { score: 100, evidence: "401 detected → token refresh path → clean retry", durationMs: performance.now() - started };
    }

    if (key === "endpoint-flap") {
      let recovered = false;
      for (let attempt = 0; attempt < 3; attempt += 1) {
        const response = await fetch(`/api/fhir?fault=${key}&attempt=${attempt}`, { cache: "no-store" });
        if (response.ok) {
          recovered = true;
          break;
        }
        await wait(180 * (attempt + 1));
      }
      if (!recovered) throw new Error("Endpoint did not recover within retry budget");
      return { score: 95, evidence: "503 isolated → bounded backoff → recovered on attempt 3", durationMs: performance.now() - started };
    }

    const response = await fetch(`/api/fhir?fault=${key}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`Unexpected HTTP ${response.status}`);
    const body = await response.json();

    if (key === "latency") {
      const elapsed = performance.now() - started;
      if (elapsed < 800) throw new Error("Latency fault was not observed");
      return { score: 92, evidence: `Slow response detected (${Math.round(elapsed)} ms) without data loss`, durationMs: elapsed };
    }

    if (key === "partial-record") {
      const types = new Set(body.entry?.map((entry: any) => entry.resource?.resourceType));
      if (types.has("MedicationRequest")) throw new Error("Expected medication data to be missing");
      return { score: 100, evidence: "Missing expected resource detected → record marked incomplete", durationMs: performance.now() - started };
    }

    if (key === "duplicate-resource") {
      const ids = body.entry?.map((entry: any) => `${entry.resource?.resourceType}/${entry.resource?.id}`) ?? [];
      if (new Set(ids).size === ids.length) throw new Error("Expected duplicate was not observed");
      return { score: 100, evidence: "Duplicate identity detected → safe deduplication gate triggered", durationMs: performance.now() - started };
    }

    if (key === "stale-data") {
      const observation = body.entry?.find((entry: any) => entry.resource?.resourceType === "Observation")?.resource;
      const ageDays = observation?.effectiveDateTime
        ? Math.floor((Date.now() - new Date(observation.effectiveDateTime).getTime()) / 86400000)
        : 0;
      if (ageDays < 365) throw new Error("Expected stale observation was not observed");
      return { score: 96, evidence: `Clinical observation flagged as stale (${ageDays} days old)`, durationMs: performance.now() - started };
    }

    throw new Error("Unknown scenario");
  }

  async function runAll() {
    if (running) return;
    setRunning(true);
    setLastRun(null);
    setResults(scenarios.map((scenario) => ({ ...scenario, status: "idle", score: 0 })));

    for (const scenario of scenarios) {
      patch(scenario.key, { status: "running" });
      try {
        const result = await runScenario(scenario.key);
        patch(scenario.key, {
          status: "pass",
          score: result.score,
          evidence: result.evidence,
          durationMs: Math.round(result.durationMs),
        });
      } catch (error) {
        patch(scenario.key, {
          status: "fail",
          score: 0,
          evidence: error instanceof Error ? error.message : "Unknown failure",
        });
      }
    }

    setLastRun(new Date().toISOString());
    setRunning(false);
  }

  function downloadEvidence() {
    const payload = {
      tool: "CareResilience Bench",
      version: "0.1.0",
      generatedAt: lastRun,
      benchmark: "synthetic-fhir-reference-client",
      overallScore: score,
      scenarios: results,
      disclaimer: "Synthetic demonstration data only. Not for clinical use.",
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `care-resilience-evidence-${Date.now()}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main>
      <nav className="nav shell">
        <div className="brand"><span className="brandMark">CR</span><span>CareResilience Bench</span></div>
        <div className="version">OPEN BENCHMARK · v0.1.0</div>
      </nav>

      <section className="hero shell">
        <div className="heroCopy">
          <div className="eyebrow">RESILIENCE TESTING FOR FHIR APPLICATIONS</div>
          <h1>Conformance is not the same as <span>surviving failure.</span></h1>
          <p className="lede">Inject realistic health-data failures, verify safe degradation, and produce repeatable evidence of how an application behaves when the ecosystem around it breaks.</p>
          <div className="heroActions">
            <button className="primary" onClick={runAll} disabled={running}>{running ? "Benchmark running…" : "Run benchmark"}</button>
            <a className="secondary" href="#scenarios">View scenarios</a>
          </div>
          <div className="micro">Synthetic data only · No PHI · Built for reproducible engineering tests</div>
        </div>

        <div className="scoreCard">
          <div className="scoreTop"><span>RESILIENCE SCORE</span><span className={running ? "pulse" : "liveDot"}></span></div>
          <div className="scoreValue">{score}<small>/100</small></div>
          <div className="meter"><div style={{ width: `${score}%` }} /></div>
          <div className="scoreMeta"><span>{completed}/6 scenarios complete</span><span>{lastRun ? "Evidence ready" : "Awaiting run"}</span></div>
          <button className="evidence" onClick={downloadEvidence} disabled={!lastRun}>Export evidence JSON</button>
        </div>
      </section>

      <section className="problem shell">
        <div><div className="kicker">THE GAP</div><h2>FHIR-valid can still be workflow-unsafe.</h2></div>
        <p>CareResilience Bench focuses on behavior under failure: whether a client detects incomplete records, handles authorization expiry, contains duplicate data, warns on stale clinical information, and recovers from transient outages without silently misrepresenting the patient record.</p>
      </section>

      <section className="scenarios shell" id="scenarios">
        <div className="sectionHeader"><div><div className="kicker">BENCHMARK SUITE 01</div><h2>Six failure modes. One repeatable run.</h2></div><span>Reference client · FHIR-shaped synthetic data</span></div>
        <div className="scenarioGrid">
          {results.map((item, index) => (
            <article className={`scenario ${item.status}`} key={item.key}>
              <div className="scenarioTop"><span className="scenarioNo">0{index + 1}</span><span className={`badge ${item.status}`}>{item.status === "idle" ? "READY" : item.status.toUpperCase()}</span></div>
              <div className="scenarioLayer">{item.layer}</div>
              <h3>{item.name}</h3>
              <p>{item.evidence ?? scenarioDescription(item.key)}</p>
              <div className="scenarioFooter"><span>{item.durationMs ? `${item.durationMs} ms` : "not run"}</span><strong>{item.score ? `${item.score}/100` : "—"}</strong></div>
            </article>
          ))}
        </div>
      </section>

      <section className="method shell">
        <div className="kicker">METHOD</div>
        <div className="methodGrid">
          <div><span>01</span><h3>Inject</h3><p>Introduce a controlled failure at the FHIR, authorization, availability, or data-integrity layer.</p></div>
          <div><span>02</span><h3>Observe</h3><p>Capture status, response behavior, retry decisions, data checks, timing, and recovery.</p></div>
          <div><span>03</span><h3>Judge</h3><p>Apply an explicit safety expectation: detect, contain, warn, retry safely, or stop the workflow.</p></div>
          <div><span>04</span><h3>Evidence</h3><p>Export a machine-readable run record that can be reproduced and compared over time.</p></div>
        </div>
      </section>

      <footer className="shell"><div><strong>CareResilience Bench</strong><p>Open resilience & failure-testing for health-data applications.</p></div><div className="footerNote">Research prototype · Synthetic data · Not for clinical decision-making</div></footer>
    </main>
  );
}

function scenarioDescription(key: string) {
  const map: Record<string, string> = {
    "latency": "Inject a slow FHIR response and verify the client detects degradation without losing or mutating data.",
    "expired-token": "Return an invalid-token challenge and verify the client follows a bounded refresh-and-retry path.",
    "partial-record": "Remove an expected clinical resource and verify the record is marked incomplete instead of silently accepted.",
    "endpoint-flap": "Alternate service failure and recovery to verify bounded retries rather than an uncontrolled retry storm.",
    "duplicate-resource": "Return the same clinical resource twice and verify identity collision is detected before display or processing.",
    "stale-data": "Return clinically plausible but old data and verify freshness checks surface the risk to the consuming workflow.",
  };
  return map[key];
}
