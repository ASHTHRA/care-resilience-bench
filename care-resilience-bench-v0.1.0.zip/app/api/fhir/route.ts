import { NextRequest, NextResponse } from "next/server";
import { healthyBundle } from "../../../lib/fhir";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export async function GET(request: NextRequest) {
  const fault = request.nextUrl.searchParams.get("fault") ?? "none";
  const attempt = Number(request.nextUrl.searchParams.get("attempt") ?? "0");

  if (fault === "latency") {
    await sleep(950);
    return NextResponse.json(healthyBundle(), { headers: { "x-care-fault": "latency" } });
  }

  if (fault === "expired-token" && attempt === 0) {
    return NextResponse.json(
      { resourceType: "OperationOutcome", issue: [{ severity: "error", code: "login", diagnostics: "Synthetic expired access token" }] },
      { status: 401, headers: { "www-authenticate": "Bearer error=\"invalid_token\"", "x-care-fault": "expired-token" } }
    );
  }

  if (fault === "endpoint-flap" && attempt < 2) {
    return NextResponse.json(
      { resourceType: "OperationOutcome", issue: [{ severity: "error", code: "transient", diagnostics: "Synthetic upstream outage" }] },
      { status: 503, headers: { "retry-after": "1", "x-care-fault": "endpoint-flap" } }
    );
  }

  if (fault === "partial-record") {
    const bundle = healthyBundle();
    bundle.entry = bundle.entry.filter((entry) => entry.resource.resourceType !== "MedicationRequest");
    bundle.total = 2;
    return NextResponse.json(bundle, { headers: { "x-care-fault": "partial-record" } });
  }

  if (fault === "duplicate-resource") {
    const bundle = healthyBundle();
    const duplicate = JSON.parse(JSON.stringify(bundle.entry[1]));
    bundle.entry.push(duplicate);
    bundle.total = 4;
    return NextResponse.json(bundle, { headers: { "x-care-fault": "duplicate-resource" } });
  }

  if (fault === "stale-data") {
    const bundle = healthyBundle();
    const observation = bundle.entry.find((entry) => entry.resource.resourceType === "Observation");
    if (observation && "effectiveDateTime" in observation.resource) {
      observation.resource.effectiveDateTime = "2024-01-15T10:00:00Z";
    }
    return NextResponse.json(bundle, { headers: { "x-care-fault": "stale-data" } });
  }

  return NextResponse.json(healthyBundle(), { headers: { "x-care-fault": "none" } });
}
